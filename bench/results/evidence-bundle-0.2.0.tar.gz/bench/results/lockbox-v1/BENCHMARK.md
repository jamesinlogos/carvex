# CarveX benchmark results

Generated: `2026-11-19T09:54:35`

Images: **20**, deleted ground-truth files: **500**, kept files: **100**, repetitions: **1**.

Tool versions:
- CarveX: `carvex 0.2.0`
- Foremost: `1.5.7`
- Scalpel: `Scalpel version 1.60`
- PhotoRec: `PhotoRec 7.2, Data Recovery Utility, February 2024`

## Method

The benchmark compares byte-exact recovery and *usable* recovery. An output is an exact true positive only if its SHA-256 equals the original deleted file. For usable matching, bytes after the real footer are ignored: the last JPEG `FF D9`, the PNG IEND chunk, or the last PDF `%%EOF`. This compensates for tools that append a NUL byte or omit a final newline. Every deleted ground-truth file can be matched once; duplicate or extra outputs are false positives. In the mixed images, recovering a file that was never deleted is also a false positive.

CarveX unallocated scans only free clusters from the FAT or NTFS `$Bitmap`; the raw rows and the other tools scan the whole image. All runtime figures are wall-clock medians of the repeated runs.

## Usable results (normalized)

| Image | FS | Scenario | Tool | Space | Out | TP | FP | FN | Prec. | Rec. | F1 | Time (s) | MiB/s |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| s1001_all-deleted_fat32 | fat32 | all-deleted | CarveX | unallocated | 30 | 30 | 0 | 0 | 100.00% | 100.00% | 100.00% | 0.123 | 520.7 |
| s1001_all-deleted_fat32 | fat32 | all-deleted | CarveX | raw | 30 | 30 | 0 | 0 | 100.00% | 100.00% | 100.00% | 0.125 | 511.9 |
| s1001_all-deleted_fat32 | fat32 | all-deleted | Foremost | raw | 39 | 28 | 11 | 2 | 71.79% | 93.33% | 81.16% | 0.322 | 199.1 |
| s1001_all-deleted_fat32 | fat32 | all-deleted | Scalpel | raw | 42 | 28 | 14 | 2 | 66.67% | 93.33% | 77.78% | 0.422 | 151.8 |
| s1001_all-deleted_fat32 | fat32 | all-deleted | PhotoRec | raw | 29 | 29 | 0 | 1 | 100.00% | 96.67% | 98.31% | 0.372 | 171.8 |
| s1002_all-deleted_fat32 | fat32 | all-deleted | CarveX | unallocated | 30 | 30 | 0 | 0 | 100.00% | 100.00% | 100.00% | 0.126 | 508.2 |
| s1002_all-deleted_fat32 | fat32 | all-deleted | CarveX | raw | 30 | 30 | 0 | 0 | 100.00% | 100.00% | 100.00% | 0.070 | 910.8 |
| s1002_all-deleted_fat32 | fat32 | all-deleted | Foremost | raw | 39 | 28 | 11 | 2 | 71.79% | 93.33% | 81.16% | 0.271 | 236.1 |
| s1002_all-deleted_fat32 | fat32 | all-deleted | Scalpel | raw | 41 | 28 | 13 | 2 | 68.29% | 93.33% | 78.87% | 0.422 | 151.5 |
| s1002_all-deleted_fat32 | fat32 | all-deleted | PhotoRec | raw | 29 | 29 | 0 | 1 | 100.00% | 96.67% | 98.31% | 0.372 | 171.8 |
| s1003_all-deleted_fat32 | fat32 | all-deleted | CarveX | unallocated | 30 | 30 | 0 | 0 | 100.00% | 100.00% | 100.00% | 0.121 | 529.9 |
| s1003_all-deleted_fat32 | fat32 | all-deleted | CarveX | raw | 30 | 30 | 0 | 0 | 100.00% | 100.00% | 100.00% | 0.072 | 894.0 |
| s1003_all-deleted_fat32 | fat32 | all-deleted | Foremost | raw | 39 | 28 | 11 | 2 | 71.79% | 93.33% | 81.16% | 0.269 | 237.7 |
| s1003_all-deleted_fat32 | fat32 | all-deleted | Scalpel | raw | 41 | 28 | 13 | 2 | 68.29% | 93.33% | 78.87% | 0.423 | 151.4 |
| s1003_all-deleted_fat32 | fat32 | all-deleted | PhotoRec | raw | 29 | 29 | 0 | 1 | 100.00% | 96.67% | 98.31% | 0.373 | 171.8 |
| s1004_all-deleted_fat32 | fat32 | all-deleted | CarveX | unallocated | 30 | 30 | 0 | 0 | 100.00% | 100.00% | 100.00% | 0.126 | 509.4 |
| s1004_all-deleted_fat32 | fat32 | all-deleted | CarveX | raw | 30 | 30 | 0 | 0 | 100.00% | 100.00% | 100.00% | 0.069 | 932.8 |
| s1004_all-deleted_fat32 | fat32 | all-deleted | Foremost | raw | 39 | 28 | 11 | 2 | 71.79% | 93.33% | 81.16% | 0.270 | 236.7 |
| s1004_all-deleted_fat32 | fat32 | all-deleted | Scalpel | raw | 42 | 28 | 14 | 2 | 66.67% | 93.33% | 77.78% | 0.422 | 151.5 |
| s1004_all-deleted_fat32 | fat32 | all-deleted | PhotoRec | raw | 29 | 29 | 0 | 1 | 100.00% | 96.67% | 98.31% | 0.370 | 173.0 |
| s1005_all-deleted_fat32 | fat32 | all-deleted | CarveX | unallocated | 30 | 30 | 0 | 0 | 100.00% | 100.00% | 100.00% | 0.125 | 510.5 |
| s1005_all-deleted_fat32 | fat32 | all-deleted | CarveX | raw | 30 | 30 | 0 | 0 | 100.00% | 100.00% | 100.00% | 0.068 | 939.2 |
| s1005_all-deleted_fat32 | fat32 | all-deleted | Foremost | raw | 39 | 28 | 11 | 2 | 71.79% | 93.33% | 81.16% | 0.270 | 237.3 |
| s1005_all-deleted_fat32 | fat32 | all-deleted | Scalpel | raw | 42 | 28 | 14 | 2 | 66.67% | 93.33% | 77.78% | 0.421 | 151.9 |
| s1005_all-deleted_fat32 | fat32 | all-deleted | PhotoRec | raw | 29 | 29 | 0 | 1 | 100.00% | 96.67% | 98.31% | 0.319 | 200.8 |
| s1006_all-deleted_ntfs | ntfs | all-deleted | CarveX | unallocated | 30 | 30 | 0 | 0 | 100.00% | 100.00% | 100.00% | 0.120 | 535.2 |
| s1006_all-deleted_ntfs | ntfs | all-deleted | CarveX | raw | 30 | 30 | 0 | 0 | 100.00% | 100.00% | 100.00% | 0.069 | 926.5 |
| s1006_all-deleted_ntfs | ntfs | all-deleted | Foremost | raw | 39 | 28 | 11 | 2 | 71.79% | 93.33% | 81.16% | 0.324 | 197.3 |
| s1006_all-deleted_ntfs | ntfs | all-deleted | Scalpel | raw | 42 | 28 | 14 | 2 | 66.67% | 93.33% | 77.78% | 0.523 | 122.3 |
| s1006_all-deleted_ntfs | ntfs | all-deleted | PhotoRec | raw | 29 | 29 | 0 | 1 | 100.00% | 96.67% | 98.31% | 0.372 | 172.2 |
| s1007_all-deleted_ntfs | ntfs | all-deleted | CarveX | unallocated | 30 | 30 | 0 | 0 | 100.00% | 100.00% | 100.00% | 0.127 | 502.1 |
| s1007_all-deleted_ntfs | ntfs | all-deleted | CarveX | raw | 30 | 30 | 0 | 0 | 100.00% | 100.00% | 100.00% | 0.072 | 883.6 |
| s1007_all-deleted_ntfs | ntfs | all-deleted | Foremost | raw | 39 | 28 | 11 | 2 | 71.79% | 93.33% | 81.16% | 0.327 | 195.4 |
| s1007_all-deleted_ntfs | ntfs | all-deleted | Scalpel | raw | 43 | 28 | 15 | 2 | 65.12% | 93.33% | 76.71% | 0.574 | 111.5 |
| s1007_all-deleted_ntfs | ntfs | all-deleted | PhotoRec | raw | 29 | 29 | 0 | 1 | 100.00% | 96.67% | 98.31% | 0.372 | 172.2 |
| s1008_all-deleted_ntfs | ntfs | all-deleted | CarveX | unallocated | 30 | 30 | 0 | 0 | 100.00% | 100.00% | 100.00% | 0.696 | 92.0 |
| s1008_all-deleted_ntfs | ntfs | all-deleted | CarveX | raw | 30 | 30 | 0 | 0 | 100.00% | 100.00% | 100.00% | 0.076 | 838.1 |
| s1008_all-deleted_ntfs | ntfs | all-deleted | Foremost | raw | 39 | 28 | 11 | 2 | 71.79% | 93.33% | 81.16% | 0.321 | 199.6 |
| s1008_all-deleted_ntfs | ntfs | all-deleted | Scalpel | raw | 43 | 28 | 15 | 2 | 65.12% | 93.33% | 76.71% | 0.578 | 110.8 |
| s1008_all-deleted_ntfs | ntfs | all-deleted | PhotoRec | raw | 29 | 29 | 0 | 1 | 100.00% | 96.67% | 98.31% | 0.320 | 199.7 |
| s1009_all-deleted_ntfs | ntfs | all-deleted | CarveX | unallocated | 30 | 30 | 0 | 0 | 100.00% | 100.00% | 100.00% | 0.183 | 349.5 |
| s1009_all-deleted_ntfs | ntfs | all-deleted | CarveX | raw | 30 | 30 | 0 | 0 | 100.00% | 100.00% | 100.00% | 0.072 | 885.7 |
| s1009_all-deleted_ntfs | ntfs | all-deleted | Foremost | raw | 39 | 28 | 11 | 2 | 71.79% | 93.33% | 81.16% | 0.371 | 172.7 |
| s1009_all-deleted_ntfs | ntfs | all-deleted | Scalpel | raw | 43 | 28 | 15 | 2 | 65.12% | 93.33% | 76.71% | 0.574 | 111.4 |
| s1009_all-deleted_ntfs | ntfs | all-deleted | PhotoRec | raw | 29 | 29 | 0 | 1 | 100.00% | 96.67% | 98.31% | 0.322 | 198.6 |
| s1010_all-deleted_ntfs | ntfs | all-deleted | CarveX | unallocated | 30 | 30 | 0 | 0 | 100.00% | 100.00% | 100.00% | 0.125 | 512.4 |
| s1010_all-deleted_ntfs | ntfs | all-deleted | CarveX | raw | 30 | 30 | 0 | 0 | 100.00% | 100.00% | 100.00% | 0.074 | 860.2 |
| s1010_all-deleted_ntfs | ntfs | all-deleted | Foremost | raw | 39 | 28 | 11 | 2 | 71.79% | 93.33% | 81.16% | 0.382 | 167.8 |
| s1010_all-deleted_ntfs | ntfs | all-deleted | Scalpel | raw | 44 | 28 | 16 | 2 | 63.64% | 93.33% | 75.68% | 0.578 | 110.8 |
| s1010_all-deleted_ntfs | ntfs | all-deleted | PhotoRec | raw | 29 | 29 | 0 | 1 | 100.00% | 96.67% | 98.31% | 0.320 | 199.7 |
| s1011_mixed_fat32 | fat32 | mixed | CarveX | unallocated | 20 | 20 | 0 | 0 | 100.00% | 100.00% | 100.00% | 0.122 | 526.7 |
| s1011_mixed_fat32 | fat32 | mixed | CarveX | raw | 30 | 20 | 10 | 0 | 66.67% | 100.00% | 80.00% | 0.124 | 516.8 |
| s1011_mixed_fat32 | fat32 | mixed | Foremost | raw | 39 | 19 | 20 | 1 | 48.72% | 95.00% | 64.41% | 0.371 | 172.5 |
| s1011_mixed_fat32 | fat32 | mixed | Scalpel | raw | 42 | 18 | 24 | 2 | 42.86% | 90.00% | 58.06% | 0.473 | 135.3 |
| s1011_mixed_fat32 | fat32 | mixed | PhotoRec | raw | 29 | 19 | 10 | 1 | 65.52% | 95.00% | 77.55% | 0.828 | 77.3 |
| s1012_mixed_fat32 | fat32 | mixed | CarveX | unallocated | 20 | 20 | 0 | 0 | 100.00% | 100.00% | 100.00% | 0.070 | 918.1 |
| s1012_mixed_fat32 | fat32 | mixed | CarveX | raw | 30 | 20 | 10 | 0 | 66.67% | 100.00% | 80.00% | 0.126 | 508.0 |
| s1012_mixed_fat32 | fat32 | mixed | Foremost | raw | 39 | 19 | 20 | 1 | 48.72% | 95.00% | 64.41% | 0.726 | 88.1 |
| s1012_mixed_fat32 | fat32 | mixed | Scalpel | raw | 41 | 18 | 23 | 2 | 43.90% | 90.00% | 59.02% | 0.473 | 135.2 |
| s1012_mixed_fat32 | fat32 | mixed | PhotoRec | raw | 29 | 19 | 10 | 1 | 65.52% | 95.00% | 77.55% | 0.831 | 77.0 |
| s1013_mixed_fat32 | fat32 | mixed | CarveX | unallocated | 20 | 20 | 0 | 0 | 100.00% | 100.00% | 100.00% | 0.122 | 525.7 |
| s1013_mixed_fat32 | fat32 | mixed | CarveX | raw | 30 | 20 | 10 | 0 | 66.67% | 100.00% | 80.00% | 0.119 | 536.5 |
| s1013_mixed_fat32 | fat32 | mixed | Foremost | raw | 39 | 19 | 20 | 1 | 48.72% | 95.00% | 64.41% | 0.423 | 151.5 |
| s1013_mixed_fat32 | fat32 | mixed | Scalpel | raw | 41 | 18 | 23 | 2 | 43.90% | 90.00% | 59.02% | 0.423 | 151.2 |
| s1013_mixed_fat32 | fat32 | mixed | PhotoRec | raw | 29 | 19 | 10 | 1 | 65.52% | 95.00% | 77.55% | 1.343 | 47.7 |
| s1014_mixed_fat32 | fat32 | mixed | CarveX | unallocated | 20 | 20 | 0 | 0 | 100.00% | 100.00% | 100.00% | 0.228 | 280.3 |
| s1014_mixed_fat32 | fat32 | mixed | CarveX | raw | 30 | 20 | 10 | 0 | 66.67% | 100.00% | 80.00% | 0.234 | 273.5 |
| s1014_mixed_fat32 | fat32 | mixed | Foremost | raw | 39 | 19 | 20 | 1 | 48.72% | 95.00% | 64.41% | 0.372 | 172.0 |
| s1014_mixed_fat32 | fat32 | mixed | Scalpel | raw | 41 | 18 | 23 | 2 | 43.90% | 90.00% | 59.02% | 0.421 | 151.9 |
| s1014_mixed_fat32 | fat32 | mixed | PhotoRec | raw | 29 | 19 | 10 | 1 | 65.52% | 95.00% | 77.55% | 0.524 | 122.2 |
| s1015_mixed_fat32 | fat32 | mixed | CarveX | unallocated | 20 | 20 | 0 | 0 | 100.00% | 100.00% | 100.00% | 0.179 | 357.8 |
| s1015_mixed_fat32 | fat32 | mixed | CarveX | raw | 30 | 20 | 10 | 0 | 66.67% | 100.00% | 80.00% | 0.127 | 504.0 |
| s1015_mixed_fat32 | fat32 | mixed | Foremost | raw | 39 | 19 | 20 | 1 | 48.72% | 95.00% | 64.41% | 0.527 | 121.5 |
| s1015_mixed_fat32 | fat32 | mixed | Scalpel | raw | 41 | 18 | 23 | 2 | 43.90% | 90.00% | 59.02% | 0.423 | 151.3 |
| s1015_mixed_fat32 | fat32 | mixed | PhotoRec | raw | 28 | 18 | 10 | 2 | 64.29% | 90.00% | 75.00% | 1.034 | 61.9 |
| s1016_mixed_ntfs | ntfs | mixed | CarveX | unallocated | 20 | 20 | 0 | 0 | 100.00% | 100.00% | 100.00% | 0.181 | 353.8 |
| s1016_mixed_ntfs | ntfs | mixed | CarveX | raw | 30 | 20 | 10 | 0 | 66.67% | 100.00% | 80.00% | 0.176 | 363.5 |
| s1016_mixed_ntfs | ntfs | mixed | Foremost | raw | 39 | 19 | 20 | 1 | 48.72% | 95.00% | 64.41% | 0.424 | 151.0 |
| s1016_mixed_ntfs | ntfs | mixed | Scalpel | raw | 44 | 18 | 26 | 2 | 40.91% | 90.00% | 56.25% | 0.575 | 111.4 |
| s1016_mixed_ntfs | ntfs | mixed | PhotoRec | raw | 29 | 19 | 10 | 1 | 65.52% | 95.00% | 77.55% | 0.828 | 77.3 |
| s1017_mixed_ntfs | ntfs | mixed | CarveX | unallocated | 20 | 20 | 0 | 0 | 100.00% | 100.00% | 100.00% | 0.334 | 191.3 |
| s1017_mixed_ntfs | ntfs | mixed | CarveX | raw | 30 | 20 | 10 | 0 | 66.67% | 100.00% | 80.00% | 0.178 | 360.6 |
| s1017_mixed_ntfs | ntfs | mixed | Foremost | raw | 39 | 19 | 20 | 1 | 48.72% | 95.00% | 64.41% | 0.474 | 135.1 |
| s1017_mixed_ntfs | ntfs | mixed | Scalpel | raw | 42 | 18 | 24 | 2 | 42.86% | 90.00% | 58.06% | 0.526 | 121.6 |
| s1017_mixed_ntfs | ntfs | mixed | PhotoRec | raw | 29 | 19 | 10 | 1 | 65.52% | 95.00% | 77.55% | 0.373 | 171.8 |
| s1018_mixed_ntfs | ntfs | mixed | CarveX | unallocated | 20 | 20 | 0 | 0 | 100.00% | 100.00% | 100.00% | 0.119 | 536.6 |
| s1018_mixed_ntfs | ntfs | mixed | CarveX | raw | 30 | 20 | 10 | 0 | 66.67% | 100.00% | 80.00% | 0.078 | 819.1 |
| s1018_mixed_ntfs | ntfs | mixed | Foremost | raw | 39 | 19 | 20 | 1 | 48.72% | 95.00% | 64.41% | 0.374 | 171.2 |
| s1018_mixed_ntfs | ntfs | mixed | Scalpel | raw | 44 | 18 | 26 | 2 | 40.91% | 90.00% | 56.25% | 0.577 | 110.8 |
| s1018_mixed_ntfs | ntfs | mixed | PhotoRec | raw | 29 | 19 | 10 | 1 | 65.52% | 95.00% | 77.55% | 0.525 | 122.0 |
| s1019_mixed_ntfs | ntfs | mixed | CarveX | unallocated | 20 | 20 | 0 | 0 | 100.00% | 100.00% | 100.00% | 0.227 | 281.7 |
| s1019_mixed_ntfs | ntfs | mixed | CarveX | raw | 30 | 20 | 10 | 0 | 66.67% | 100.00% | 80.00% | 0.121 | 529.2 |
| s1019_mixed_ntfs | ntfs | mixed | Foremost | raw | 39 | 19 | 20 | 1 | 48.72% | 95.00% | 64.41% | 0.524 | 122.1 |
| s1019_mixed_ntfs | ntfs | mixed | Scalpel | raw | 44 | 18 | 26 | 2 | 40.91% | 90.00% | 56.25% | 0.524 | 122.1 |
| s1019_mixed_ntfs | ntfs | mixed | PhotoRec | raw | 29 | 19 | 10 | 1 | 65.52% | 95.00% | 77.55% | 0.422 | 151.5 |
| s1020_mixed_ntfs | ntfs | mixed | CarveX | unallocated | 20 | 20 | 0 | 0 | 100.00% | 100.00% | 100.00% | 0.071 | 903.2 |
| s1020_mixed_ntfs | ntfs | mixed | CarveX | raw | 30 | 20 | 10 | 0 | 66.67% | 100.00% | 80.00% | 0.122 | 526.3 |
| s1020_mixed_ntfs | ntfs | mixed | Foremost | raw | 39 | 19 | 20 | 1 | 48.72% | 95.00% | 64.41% | 0.320 | 200.1 |
| s1020_mixed_ntfs | ntfs | mixed | Scalpel | raw | 42 | 18 | 24 | 2 | 42.86% | 90.00% | 58.06% | 0.523 | 122.4 |
| s1020_mixed_ntfs | ntfs | mixed | PhotoRec | raw | 29 | 19 | 10 | 1 | 65.52% | 95.00% | 77.55% | 0.525 | 121.8 |

## Exact results (SHA-256)

| Image | FS | Scenario | Tool | Space | Out | TP | FP | FN | Prec. | Rec. | F1 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| s1001_all-deleted_fat32 | fat32 | all-deleted | CarveX | unallocated | 30 | 30 | 0 | 0 | 100.00% | 100.00% | 100.00% |
| s1001_all-deleted_fat32 | fat32 | all-deleted | CarveX | raw | 30 | 30 | 0 | 0 | 100.00% | 100.00% | 100.00% |
| s1001_all-deleted_fat32 | fat32 | all-deleted | Foremost | raw | 39 | 23 | 16 | 7 | 58.97% | 76.67% | 66.67% |
| s1001_all-deleted_fat32 | fat32 | all-deleted | Scalpel | raw | 42 | 24 | 18 | 6 | 57.14% | 80.00% | 66.67% |
| s1001_all-deleted_fat32 | fat32 | all-deleted | PhotoRec | raw | 29 | 29 | 0 | 1 | 100.00% | 96.67% | 98.31% |
| s1002_all-deleted_fat32 | fat32 | all-deleted | CarveX | unallocated | 30 | 30 | 0 | 0 | 100.00% | 100.00% | 100.00% |
| s1002_all-deleted_fat32 | fat32 | all-deleted | CarveX | raw | 30 | 30 | 0 | 0 | 100.00% | 100.00% | 100.00% |
| s1002_all-deleted_fat32 | fat32 | all-deleted | Foremost | raw | 39 | 23 | 16 | 7 | 58.97% | 76.67% | 66.67% |
| s1002_all-deleted_fat32 | fat32 | all-deleted | Scalpel | raw | 41 | 24 | 17 | 6 | 58.54% | 80.00% | 67.61% |
| s1002_all-deleted_fat32 | fat32 | all-deleted | PhotoRec | raw | 29 | 29 | 0 | 1 | 100.00% | 96.67% | 98.31% |
| s1003_all-deleted_fat32 | fat32 | all-deleted | CarveX | unallocated | 30 | 30 | 0 | 0 | 100.00% | 100.00% | 100.00% |
| s1003_all-deleted_fat32 | fat32 | all-deleted | CarveX | raw | 30 | 30 | 0 | 0 | 100.00% | 100.00% | 100.00% |
| s1003_all-deleted_fat32 | fat32 | all-deleted | Foremost | raw | 39 | 23 | 16 | 7 | 58.97% | 76.67% | 66.67% |
| s1003_all-deleted_fat32 | fat32 | all-deleted | Scalpel | raw | 41 | 24 | 17 | 6 | 58.54% | 80.00% | 67.61% |
| s1003_all-deleted_fat32 | fat32 | all-deleted | PhotoRec | raw | 29 | 29 | 0 | 1 | 100.00% | 96.67% | 98.31% |
| s1004_all-deleted_fat32 | fat32 | all-deleted | CarveX | unallocated | 30 | 30 | 0 | 0 | 100.00% | 100.00% | 100.00% |
| s1004_all-deleted_fat32 | fat32 | all-deleted | CarveX | raw | 30 | 30 | 0 | 0 | 100.00% | 100.00% | 100.00% |
| s1004_all-deleted_fat32 | fat32 | all-deleted | Foremost | raw | 39 | 23 | 16 | 7 | 58.97% | 76.67% | 66.67% |
| s1004_all-deleted_fat32 | fat32 | all-deleted | Scalpel | raw | 42 | 24 | 18 | 6 | 57.14% | 80.00% | 66.67% |
| s1004_all-deleted_fat32 | fat32 | all-deleted | PhotoRec | raw | 29 | 29 | 0 | 1 | 100.00% | 96.67% | 98.31% |
| s1005_all-deleted_fat32 | fat32 | all-deleted | CarveX | unallocated | 30 | 30 | 0 | 0 | 100.00% | 100.00% | 100.00% |
| s1005_all-deleted_fat32 | fat32 | all-deleted | CarveX | raw | 30 | 30 | 0 | 0 | 100.00% | 100.00% | 100.00% |
| s1005_all-deleted_fat32 | fat32 | all-deleted | Foremost | raw | 39 | 23 | 16 | 7 | 58.97% | 76.67% | 66.67% |
| s1005_all-deleted_fat32 | fat32 | all-deleted | Scalpel | raw | 42 | 24 | 18 | 6 | 57.14% | 80.00% | 66.67% |
| s1005_all-deleted_fat32 | fat32 | all-deleted | PhotoRec | raw | 29 | 29 | 0 | 1 | 100.00% | 96.67% | 98.31% |
| s1006_all-deleted_ntfs | ntfs | all-deleted | CarveX | unallocated | 30 | 30 | 0 | 0 | 100.00% | 100.00% | 100.00% |
| s1006_all-deleted_ntfs | ntfs | all-deleted | CarveX | raw | 30 | 30 | 0 | 0 | 100.00% | 100.00% | 100.00% |
| s1006_all-deleted_ntfs | ntfs | all-deleted | Foremost | raw | 39 | 23 | 16 | 7 | 58.97% | 76.67% | 66.67% |
| s1006_all-deleted_ntfs | ntfs | all-deleted | Scalpel | raw | 42 | 24 | 18 | 6 | 57.14% | 80.00% | 66.67% |
| s1006_all-deleted_ntfs | ntfs | all-deleted | PhotoRec | raw | 29 | 29 | 0 | 1 | 100.00% | 96.67% | 98.31% |
| s1007_all-deleted_ntfs | ntfs | all-deleted | CarveX | unallocated | 30 | 30 | 0 | 0 | 100.00% | 100.00% | 100.00% |
| s1007_all-deleted_ntfs | ntfs | all-deleted | CarveX | raw | 30 | 30 | 0 | 0 | 100.00% | 100.00% | 100.00% |
| s1007_all-deleted_ntfs | ntfs | all-deleted | Foremost | raw | 39 | 23 | 16 | 7 | 58.97% | 76.67% | 66.67% |
| s1007_all-deleted_ntfs | ntfs | all-deleted | Scalpel | raw | 43 | 24 | 19 | 6 | 55.81% | 80.00% | 65.75% |
| s1007_all-deleted_ntfs | ntfs | all-deleted | PhotoRec | raw | 29 | 29 | 0 | 1 | 100.00% | 96.67% | 98.31% |
| s1008_all-deleted_ntfs | ntfs | all-deleted | CarveX | unallocated | 30 | 30 | 0 | 0 | 100.00% | 100.00% | 100.00% |
| s1008_all-deleted_ntfs | ntfs | all-deleted | CarveX | raw | 30 | 30 | 0 | 0 | 100.00% | 100.00% | 100.00% |
| s1008_all-deleted_ntfs | ntfs | all-deleted | Foremost | raw | 39 | 23 | 16 | 7 | 58.97% | 76.67% | 66.67% |
| s1008_all-deleted_ntfs | ntfs | all-deleted | Scalpel | raw | 43 | 24 | 19 | 6 | 55.81% | 80.00% | 65.75% |
| s1008_all-deleted_ntfs | ntfs | all-deleted | PhotoRec | raw | 29 | 29 | 0 | 1 | 100.00% | 96.67% | 98.31% |
| s1009_all-deleted_ntfs | ntfs | all-deleted | CarveX | unallocated | 30 | 30 | 0 | 0 | 100.00% | 100.00% | 100.00% |
| s1009_all-deleted_ntfs | ntfs | all-deleted | CarveX | raw | 30 | 30 | 0 | 0 | 100.00% | 100.00% | 100.00% |
| s1009_all-deleted_ntfs | ntfs | all-deleted | Foremost | raw | 39 | 23 | 16 | 7 | 58.97% | 76.67% | 66.67% |
| s1009_all-deleted_ntfs | ntfs | all-deleted | Scalpel | raw | 43 | 24 | 19 | 6 | 55.81% | 80.00% | 65.75% |
| s1009_all-deleted_ntfs | ntfs | all-deleted | PhotoRec | raw | 29 | 29 | 0 | 1 | 100.00% | 96.67% | 98.31% |
| s1010_all-deleted_ntfs | ntfs | all-deleted | CarveX | unallocated | 30 | 30 | 0 | 0 | 100.00% | 100.00% | 100.00% |
| s1010_all-deleted_ntfs | ntfs | all-deleted | CarveX | raw | 30 | 30 | 0 | 0 | 100.00% | 100.00% | 100.00% |
| s1010_all-deleted_ntfs | ntfs | all-deleted | Foremost | raw | 39 | 23 | 16 | 7 | 58.97% | 76.67% | 66.67% |
| s1010_all-deleted_ntfs | ntfs | all-deleted | Scalpel | raw | 44 | 24 | 20 | 6 | 54.55% | 80.00% | 64.86% |
| s1010_all-deleted_ntfs | ntfs | all-deleted | PhotoRec | raw | 29 | 29 | 0 | 1 | 100.00% | 96.67% | 98.31% |
| s1011_mixed_fat32 | fat32 | mixed | CarveX | unallocated | 20 | 20 | 0 | 0 | 100.00% | 100.00% | 100.00% |
| s1011_mixed_fat32 | fat32 | mixed | CarveX | raw | 30 | 20 | 10 | 0 | 66.67% | 100.00% | 80.00% |
| s1011_mixed_fat32 | fat32 | mixed | Foremost | raw | 39 | 16 | 23 | 4 | 41.03% | 80.00% | 54.24% |
| s1011_mixed_fat32 | fat32 | mixed | Scalpel | raw | 42 | 15 | 27 | 5 | 35.71% | 75.00% | 48.39% |
| s1011_mixed_fat32 | fat32 | mixed | PhotoRec | raw | 29 | 19 | 10 | 1 | 65.52% | 95.00% | 77.55% |
| s1012_mixed_fat32 | fat32 | mixed | CarveX | unallocated | 20 | 20 | 0 | 0 | 100.00% | 100.00% | 100.00% |
| s1012_mixed_fat32 | fat32 | mixed | CarveX | raw | 30 | 20 | 10 | 0 | 66.67% | 100.00% | 80.00% |
| s1012_mixed_fat32 | fat32 | mixed | Foremost | raw | 39 | 16 | 23 | 4 | 41.03% | 80.00% | 54.24% |
| s1012_mixed_fat32 | fat32 | mixed | Scalpel | raw | 41 | 15 | 26 | 5 | 36.59% | 75.00% | 49.18% |
| s1012_mixed_fat32 | fat32 | mixed | PhotoRec | raw | 29 | 19 | 10 | 1 | 65.52% | 95.00% | 77.55% |
| s1013_mixed_fat32 | fat32 | mixed | CarveX | unallocated | 20 | 20 | 0 | 0 | 100.00% | 100.00% | 100.00% |
| s1013_mixed_fat32 | fat32 | mixed | CarveX | raw | 30 | 20 | 10 | 0 | 66.67% | 100.00% | 80.00% |
| s1013_mixed_fat32 | fat32 | mixed | Foremost | raw | 39 | 16 | 23 | 4 | 41.03% | 80.00% | 54.24% |
| s1013_mixed_fat32 | fat32 | mixed | Scalpel | raw | 41 | 15 | 26 | 5 | 36.59% | 75.00% | 49.18% |
| s1013_mixed_fat32 | fat32 | mixed | PhotoRec | raw | 29 | 19 | 10 | 1 | 65.52% | 95.00% | 77.55% |
| s1014_mixed_fat32 | fat32 | mixed | CarveX | unallocated | 20 | 20 | 0 | 0 | 100.00% | 100.00% | 100.00% |
| s1014_mixed_fat32 | fat32 | mixed | CarveX | raw | 30 | 20 | 10 | 0 | 66.67% | 100.00% | 80.00% |
| s1014_mixed_fat32 | fat32 | mixed | Foremost | raw | 39 | 16 | 23 | 4 | 41.03% | 80.00% | 54.24% |
| s1014_mixed_fat32 | fat32 | mixed | Scalpel | raw | 41 | 15 | 26 | 5 | 36.59% | 75.00% | 49.18% |
| s1014_mixed_fat32 | fat32 | mixed | PhotoRec | raw | 29 | 19 | 10 | 1 | 65.52% | 95.00% | 77.55% |
| s1015_mixed_fat32 | fat32 | mixed | CarveX | unallocated | 20 | 20 | 0 | 0 | 100.00% | 100.00% | 100.00% |
| s1015_mixed_fat32 | fat32 | mixed | CarveX | raw | 30 | 20 | 10 | 0 | 66.67% | 100.00% | 80.00% |
| s1015_mixed_fat32 | fat32 | mixed | Foremost | raw | 39 | 16 | 23 | 4 | 41.03% | 80.00% | 54.24% |
| s1015_mixed_fat32 | fat32 | mixed | Scalpel | raw | 41 | 15 | 26 | 5 | 36.59% | 75.00% | 49.18% |
| s1015_mixed_fat32 | fat32 | mixed | PhotoRec | raw | 28 | 18 | 10 | 2 | 64.29% | 90.00% | 75.00% |
| s1016_mixed_ntfs | ntfs | mixed | CarveX | unallocated | 20 | 20 | 0 | 0 | 100.00% | 100.00% | 100.00% |
| s1016_mixed_ntfs | ntfs | mixed | CarveX | raw | 30 | 20 | 10 | 0 | 66.67% | 100.00% | 80.00% |
| s1016_mixed_ntfs | ntfs | mixed | Foremost | raw | 39 | 16 | 23 | 4 | 41.03% | 80.00% | 54.24% |
| s1016_mixed_ntfs | ntfs | mixed | Scalpel | raw | 44 | 15 | 29 | 5 | 34.09% | 75.00% | 46.88% |
| s1016_mixed_ntfs | ntfs | mixed | PhotoRec | raw | 29 | 19 | 10 | 1 | 65.52% | 95.00% | 77.55% |
| s1017_mixed_ntfs | ntfs | mixed | CarveX | unallocated | 20 | 20 | 0 | 0 | 100.00% | 100.00% | 100.00% |
| s1017_mixed_ntfs | ntfs | mixed | CarveX | raw | 30 | 20 | 10 | 0 | 66.67% | 100.00% | 80.00% |
| s1017_mixed_ntfs | ntfs | mixed | Foremost | raw | 39 | 16 | 23 | 4 | 41.03% | 80.00% | 54.24% |
| s1017_mixed_ntfs | ntfs | mixed | Scalpel | raw | 42 | 15 | 27 | 5 | 35.71% | 75.00% | 48.39% |
| s1017_mixed_ntfs | ntfs | mixed | PhotoRec | raw | 29 | 19 | 10 | 1 | 65.52% | 95.00% | 77.55% |
| s1018_mixed_ntfs | ntfs | mixed | CarveX | unallocated | 20 | 20 | 0 | 0 | 100.00% | 100.00% | 100.00% |
| s1018_mixed_ntfs | ntfs | mixed | CarveX | raw | 30 | 20 | 10 | 0 | 66.67% | 100.00% | 80.00% |
| s1018_mixed_ntfs | ntfs | mixed | Foremost | raw | 39 | 16 | 23 | 4 | 41.03% | 80.00% | 54.24% |
| s1018_mixed_ntfs | ntfs | mixed | Scalpel | raw | 44 | 15 | 29 | 5 | 34.09% | 75.00% | 46.88% |
| s1018_mixed_ntfs | ntfs | mixed | PhotoRec | raw | 29 | 19 | 10 | 1 | 65.52% | 95.00% | 77.55% |
| s1019_mixed_ntfs | ntfs | mixed | CarveX | unallocated | 20 | 20 | 0 | 0 | 100.00% | 100.00% | 100.00% |
| s1019_mixed_ntfs | ntfs | mixed | CarveX | raw | 30 | 20 | 10 | 0 | 66.67% | 100.00% | 80.00% |
| s1019_mixed_ntfs | ntfs | mixed | Foremost | raw | 39 | 16 | 23 | 4 | 41.03% | 80.00% | 54.24% |
| s1019_mixed_ntfs | ntfs | mixed | Scalpel | raw | 44 | 15 | 29 | 5 | 34.09% | 75.00% | 46.88% |
| s1019_mixed_ntfs | ntfs | mixed | PhotoRec | raw | 29 | 19 | 10 | 1 | 65.52% | 95.00% | 77.55% |
| s1020_mixed_ntfs | ntfs | mixed | CarveX | unallocated | 20 | 20 | 0 | 0 | 100.00% | 100.00% | 100.00% |
| s1020_mixed_ntfs | ntfs | mixed | CarveX | raw | 30 | 20 | 10 | 0 | 66.67% | 100.00% | 80.00% |
| s1020_mixed_ntfs | ntfs | mixed | Foremost | raw | 39 | 16 | 23 | 4 | 41.03% | 80.00% | 54.24% |
| s1020_mixed_ntfs | ntfs | mixed | Scalpel | raw | 42 | 15 | 27 | 5 | 35.71% | 75.00% | 48.39% |
| s1020_mixed_ntfs | ntfs | mixed | PhotoRec | raw | 29 | 19 | 10 | 1 | 65.52% | 95.00% | 77.55% |

## Pooled by tool

| Tool | Space | Deleted | Out | TP | FP | FN | Prec. | Rec. | F1 | Total time (s) | MiB/s |
|---|---|---|---|---|---|---|---|---|---|---|---|
| CarveX | unallocated | 500 | 500 | 500 | 0 | 0 | 100.00% | 100.00% | 100.00% | 3.524 | 363.2 |
| CarveX | raw | 500 | 600 | 500 | 100 | 0 | 83.33% | 100.00% | 90.91% | 2.173 | 589.2 |
| Foremost | raw | 500 | 780 | 470 | 310 | 30 | 60.26% | 94.00% | 73.44% | 7.660 | 167.1 |
| Scalpel | raw | 500 | 845 | 460 | 385 | 40 | 54.44% | 92.00% | 68.40% | 9.877 | 129.6 |
| PhotoRec | raw | 500 | 579 | 479 | 100 | 21 | 82.73% | 95.80% | 88.79% | 10.745 | 119.1 |

### Pooled exact results

| Tool | Space | TP | FP | FN | Prec. | Rec. | F1 |
|---|---|---|---|---|---|---|---|
| CarveX | unallocated | 500 | 0 | 0 | 100.00% | 100.00% | 100.00% |
| CarveX | raw | 500 | 100 | 0 | 83.33% | 100.00% | 90.91% |
| Foremost | raw | 390 | 390 | 110 | 50.00% | 78.00% | 60.94% |
| Scalpel | raw | 390 | 455 | 110 | 46.15% | 78.00% | 57.99% |
| PhotoRec | raw | 479 | 100 | 21 | 82.73% | 95.80% | 88.79% |

## Commands

```text
carvex scan IMAGE -o OUT --mode unallocated --types jpeg,png,pdf --partition largest --no-gaps --min-score 50 --quiet
carvex scan IMAGE -o OUT --mode raw --no-fs --types jpeg,png,pdf --partition largest --no-gaps --min-score 50 --quiet
foremost -Q -c bench/foremost.conf -t jpg,png,pdf -i IMAGE -o OUT
scalpel -c bench/scalpel.conf -o OUT IMAGE
photorec /log /d OUT /cmd IMAGE partition_i386,1,fileopt,everything,disable,jpg,enable,png,enable,pdf,enable,search
```

## Notes

- `Out` counts every recognized target file in the tool output, including duplicates and invalid files with a target extension.
- `kept_outputs` (in the CSV/JSON) separates false positives caused by recovering allocated files from other false positives.
- Foremost's built-in signatures are used (its packaged config file has no enabled types). Adding custom JPEG/PDF entries to the config registers a second signature and produces duplicate carvings.
- The 64 MiB images are small, warm-cache benchmark media. Runtime is reported for comparison, not as a claim about large disks.

